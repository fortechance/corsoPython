"""
Global constants for Forge.
"""
DISPLAY_OBJECT_RENDERER = 'display-object-renderer'
DISPLAY_UI_RENDERER = 'display-ui-renderer'
DISPLAY_COMPONENT_RENDERER = 'display-component-renderer'
