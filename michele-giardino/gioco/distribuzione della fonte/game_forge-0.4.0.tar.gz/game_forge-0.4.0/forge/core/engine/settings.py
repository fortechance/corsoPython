"""
Global settings for Forge.
"""
# Automatic addition to renderer settings.
AUTO_ADD_IMAGES = False
AUTO_ADD_STATIC_BODIES = False
AUTO_ADD_RIGID_BODIES = False
AUTO_ADD_LINES = False
